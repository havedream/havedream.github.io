So. This is the auto-tile for the construct.
Check out the demo to understand what it is about.
This can help you quickly build levels.
Most likely it will work in construct3, I did not check.

How to remake it for yourself:
Inside the archive you will find the project file itself and the tilemap.
Redraw the tiles on your own, replace the size of the map tile in the project with current ones and that’s it.

For example, in the folder you found the dummy16x16.png file. Replace the tilemap inside the project on it.
Change the tile size to 16x16 and start the project.

To fully understand how it works, please read
https://gamedevelopment.tutsplus.com/tutorials/how-to-use-tile-bitmasking-to-auto-tile-your-level-layouts--cms-25673

